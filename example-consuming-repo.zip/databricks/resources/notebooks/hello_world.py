# Databricks notebook source
# MAGIC %md
# MAGIC # Hello World (Bundle Example)
# MAGIC This notebook is deployed as part of the Databricks Asset Bundle.

# COMMAND ----------
print("Hello from the example bundle!")
